//import http module
var http=require("http");
var url=require("url");

//create a server
var server=http.createServer(function(request,response){
  
    var myURL=new url.URL("http://localhost:8081"+request.url); 
  
    var accno=myURL.searchParams.get("accno");
    var name=myURL.searchParams.get("name");
    var balance=myURL.searchParams.get("balance");
    
   var result ="Accno  :"+accno+",   Name :"+name+"   Balance :"+balance;
  
    response.end(result);

});


//maker server listening on port
server.listen(8081,function(){
    console.log("Node JS Server lsitneing on port 8081");
});




