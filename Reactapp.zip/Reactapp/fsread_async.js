var fs=require("fs");


fs.readFile("osdemo.js",function(err,data){
console.log("Contents :\n================="+data);
})


console.log("File Reading completed");
