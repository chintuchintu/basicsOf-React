//import the os module
var ts=require("timers");


var timer=ts.setInterval(welcome,1000);


function welcome(){
    console.log("Welcome To Timers module at Atos");
}

function clear(){
    ts.clearInterval(timer);
}

ts.setTimeout(clear,10000);
