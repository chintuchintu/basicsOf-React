//import http module
var http=require("http");

//create a server
var server=http.createServer(function(request,response){
  response.end("Hello All!!! Welcome to Node JS App");
});

//maker server listening on port
server.listen(8081,function(){
    console.log("Node JS Server lsitneing on port 8081");
});




