var events=require("events");

var emitter=new events.EventEmitter();


//handle connect event
emitter.on("connect",function(){
console.log("Client is connected to server");
emitter.emit("data");

});

//handle data event
emitter.addListener("data",function(){
    console.log("Server received the data from client");
});
    

//fire connect event
emitter.emit("connect");

console.log("Event Handling Over");
